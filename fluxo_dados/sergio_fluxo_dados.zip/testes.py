#%%
import pandas as pd 
import numpy as np 

nomes = '''
PEDRO SOARES
Maria Antonieta Pedrosa
Joana dark
Manuel Bandeira Filho
João Paulo barroso filho1
354621303-888
\tlais soares filho
'''.split('\n')[:-1]
#%%
id_cliente = np.random.randint(1000,9000, len(nomes))
#%%
idades = np.random.randint(20,50,len(nomes))

cep = np.random.randint(100000000,900000000, len(nomes))
cep = [(str(x)[:5] + '-' + str(x)[6:]) for x in cep]
cep

#%%
lala1 = {x:eval(x) for x in 'id_cliente nomes idades cep'.split()}
#%%

df_clientes = pd.DataFrame(lala1)
df_clientes.to_excel('entrada//clientes.xlsx')
# %%

f_dia = lambda: np.random.randint(1,28)
f_mes = lambda: np.random.randint(1,12)
f_data = lambda: f'2020-{f_mes()}-{f_dia()}'

data_venda = [f_data() for x in range(1000)]
id_do_cliente = [np.random.choice(id_cliente) for x in range(1000)]

# %%
valor_venda = [float(f'{np.random.random()*100:,.2}') for x in range(1000)]

# %%
lala2 = {x:eval(x) for x in 'data_venda id_do_cliente valor_venda'.split()}

df_venda = pd.DataFrame(lala2)
df_venda.to_excel('entrada//vendas.xlsx')
# %%

# %%
