#%%
import pandas as pd 
import re 
import time
from unidecode import unidecode
import os
import functools
import logging 

def hora():
    return time.ctime()[10:19]

try: os.remove('log/log_funcoes.log')
except: pass
### FAZER LOGS
def logar_mensagem(message):
    logging.basicConfig(filename = 'log//log_funcoes.log', 
                format = '%(message)s',                    
                level = logging.WARNING)
    logging.warning(message)
    logging.shutdown()


### DECORADORES
def decorador_tabela(func):    
    @functools.wraps(func)
    def proxy(*args):
        logar_mensagem(f'{hora()} - tabela {func.__name__[2:]}')
        return func(*args)
    return proxy

def decorador_funcao(func):        
    @functools.wraps(func)
    def proxy(*args):        
        logar_mensagem(f'\t\t -> {func.__name__} ')
        return func(*args)
    return proxy

@decorador_funcao
def f_arrumar_nomes(tabela, coluna):
    dataset = tabela.copy()
    dataset.loc[:,coluna] = dataset[coluna].astype(str).str.upper().apply(unidecode).str.replace('[^A-Z\s]','').str.replace('\t','')
    logar_mensagem(f'\t\t\t -> {coluna}')
    return dataset

@decorador_funcao
def f_renomear_coluna(tabela, dicionario_colunas):
    dataset = tabela.copy()
    dataset.rename(columns = dicionario_colunas, inplace = True)
    logar_mensagem(f'\t\t\t -> {dicionario_colunas}')
    return dataset

@decorador_funcao
def f_tratar_vazia(tabela, coluna, tratamento = 'drop'):
    """ 
        f_tratar_vazia(dataset, 'nomes', 'drop')
        se 'drop': remover linhas que tenha valor vazio
        se 'zero': preencher linha vazia com zero
    """
    logar_mensagem(f'\t\t\t -> tratamento: {tratamento}')
    if tratamento == 'drop':
        tabela = tabela.dropna(subset = [coluna])
        return tabela
    elif tratamento == 'zero':
        tabela.loc[:,coluna] = tabela.coluna.fillna(0)
    return tabela

def f_listar_tabelas_entrada():    
    return os.listdir('entrada')


# %%

import functools

def decorador_inutil(func):
    '''docstring do decorador_inutil'''
    print('decorador_inutil atribuído à ', func.__name__)
    @functools.wraps(func)
    def proxy(*args):
        '''docstring do proxy'''
        print(f'{func.__name__} executada')
        logar_mensagem(f'\t\t -> {func.__name__}, {args}')        
        return func(*args)
    return proxy

@decorador_inutil
def funcao_inutil(x):
    '''docstring da funcao_inutil'''
    return x
    