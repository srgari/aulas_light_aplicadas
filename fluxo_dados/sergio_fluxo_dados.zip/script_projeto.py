"""
Projeto teste
Criado por Sergio Marinho da Silva
Apenas para fins educativos

Todos os dados são meramente ilustrativos e criados aleatoriamente.
Todos os esquerdos reservados.

Última modificação: 14/11/2020

Explicando coisas para turma da aula light

lala lala lala lala

"""


#%%
from script_utils import *
#%%
class Tabelas_importadas():
    def __init__(self):
        logar_mensagem(f'carragando tabelas: {f_listar_tabelas_entrada()}')
        self.original_cliente = pd.read_excel('entrada//clientes.xlsx')
        self.original_vendas = pd.read_excel('entrada//vendas.xlsx')

    def __repr__(self):
        return str([x for x in dir(self) if '__' not in x and x[:2] != 'f_'])

tabelas_importadas = Tabelas_importadas()
#%%
class Tabelas_tratadas():
    def __init__(self):
        self.tratado_cliente = self.f_tratado_cliente()
        self.tratado_vendas = self.f_tratado_vendas()
    
    @decorador_tabela
    def f_tratado_cliente(self):
        dataset = tabelas_importadas.original_cliente.copy()
        dataset = f_tratar_vazia(dataset, 'nomes', 'drop')
        dataset = f_arrumar_nomes(dataset, 'nomes')
        
        return dataset

    @decorador_tabela
    def f_tratado_vendas(self):
        dataset = tabelas_importadas.original_vendas.copy()
        dic_nomes = {'id_do_cliente':'id_cliente'}
        dataset = f_renomear_coluna(dataset, dic_nomes)
        cols_saida = [
                    # 'Unnamed: 0', 
                    'data_venda', 
                    'id_cliente', 
                    'valor_venda'
                    ]
        dataset['data_venda'] = pd.to_datetime(dataset.data_venda)
        dataset = dataset[cols_saida]
        return dataset 

    def __repr__(self):
        return str([x for x in dir(self) if '__' not in x and x[:2] != 'f_'])
tabelas_tratadas = Tabelas_tratadas()

#%%
class Tabelas_transformadas:
    def __init__(self):
        self.tabela_final = self.f_tabela_final()

    @decorador_tabela
    def f_tabela_final(self):
        df_cliente = tabelas_tratadas.tratado_cliente.copy()
        df_vendas = tabelas_tratadas.tratado_vendas.copy()
        logar_mensagem('\t -> Mesclar tabelas via id_cliente')
        dataset = pd.merge(left = df_cliente,
                            right = df_vendas,
                            on = 'id_cliente',
                            how = 'right')
        logar_mensagem('\t -> agrupar por mes de venda e cliente; somar vendas')
        dataset = dataset.groupby( 'nomes').valor_venda.sum()
        dataset.to_excel('saida//tabela_final.xlsx')
        return dataset
    
    def __repr__(self):
        return str([x for x in dir(self) if '__' not in x and x[:2] != 'f_'])
tabelas_transformadas = Tabelas_transformadas() 

tabelas_transformadas.tabela_final

# %%

# %%
logging.shutdown()
# %%
